package com.example.searchbooks.viewmodel


import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.searchbooks.model.Data
import com.example.searchbooks.repository.BooksRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


class MainViewModel(private val booksRepository: BooksRepository): ViewModel()  {


    init {
        viewModelScope.launch ( Dispatchers.IO ){
            booksRepository.getBooksData("harry","rowling")
        }

    }

    val books : LiveData<Data>
        get()= booksRepository.books


// ************************** Another Method ********************







}