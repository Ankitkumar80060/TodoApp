package com.example.searchbooks.model

data class ListPriceX(
    val amountInMicros: Int,
    val currencyCode: String
)