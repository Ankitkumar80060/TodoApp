package com.example.searchbooks.retrofit

import com.example.searchbooks.model.Data
import com.example.searchbooks.model.Item
import com.example.searchbooks.model.VolumeInfo
import retrofit2.Call
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface BooksApi {
    // service

    @GET("/books/v1/volumes")
    suspend fun getBooks(@Query("q") query:  String, @Query("inauthor") author: String): Response<Data>

// ************************** Another Method ********************

//    @GET("/books/v1/volumes")
//     fun getBooks(
//        @Query("q") query: String,
//        @Query("inauthor") author: String
//    ): Call<Data>

}