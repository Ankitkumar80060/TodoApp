package com.example.searchbooks.model

data class SearchInfo(
    val textSnippet: String
)