package com.example.searchbooks.repository

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.searchbooks.model.Data
import com.example.searchbooks.retrofit.BooksApi
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class BooksRepository(private var booksApi: BooksApi) {

    var booksLiveData= MutableLiveData<Data>()

    val books: LiveData<Data>
        get() = booksLiveData

    suspend fun  getBooksData(query :String,author:String) {
        val result = booksApi.getBooks(query, author)
        Log.d("result", result.body().toString())
        if (result.body() != null) {
            booksLiveData.postValue(result.body())

        }
    }

// ************************** Another Method ********************

//     fun  getBookRecords(query :String,author:String){
//        booksApi.getBooks(query,author)
//            .enqueue(object :Callback<Data>{
//                override fun onResponse(call: Call<Data>, response: Response<Data>) {
//                    if(response.body() !=null){
//                        booksLiveData.postValue(response.body())
//                        Log.d("data",response.body().toString())
//                    }
//                }
//                override fun onFailure(call: Call<Data>, t: Throwable) {
//                }
//            })
//
//    }
//
//    fun getVolumesResponseLiveData(): LiveData<Data> {
//        return booksLiveData
//    }



}