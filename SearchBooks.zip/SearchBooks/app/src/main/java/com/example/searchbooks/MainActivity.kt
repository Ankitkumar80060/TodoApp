package com.example.searchbooks

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.searchbooks.adapter.MyAdapter
import com.example.searchbooks.databinding.ActivityMainBinding
import com.example.searchbooks.model.Data
import com.example.searchbooks.model.Item
import com.example.searchbooks.model.VolumeInfo
import com.example.searchbooks.repository.BooksRepository
import com.example.searchbooks.retrofit.BooksApi
import com.example.searchbooks.retrofit.RetrofitHelper
import com.example.searchbooks.viewmodel.MainViewModel
import com.example.searchbooks.viewmodel.MainViewModelFactory
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding

    lateinit var mainViewModel: MainViewModel
//    lateinit var text1:TextView

    lateinit var myAdapter: MyAdapter
    lateinit var linearLayoutManager: LinearLayoutManager

    var data = ArrayList<Item>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

// *************** Recycler view ******************

        binding.recylerViewList.layoutManager = LinearLayoutManager(this)


//      text1=findViewById(R.id.textView)

        val booksApi = RetrofitHelper.getInstance().create(BooksApi::class.java)

        val booksRepository = BooksRepository(booksApi)

        mainViewModel = ViewModelProvider(
            this,
            MainViewModelFactory(booksRepository)
        )[MainViewModel::class.java]




        mainViewModel.books.observe(this, Observer {

// ********************** check the data of api in logcat show in Recycler View *********************
            Log.d("Rinku", it.items.get(0).volumeInfo.toString())

            data = it.items as ArrayList<Item>
            myAdapter = MyAdapter(data)
            binding.recylerViewList.adapter = myAdapter


            // complete show data from the api
            // Log.d("Rinku",it.toString())

            // or
            //  Log.d("data","onCreate:${it.toString()}")

// ********************** Check particular data is show or not in Logcat *********************

//            it.items.iterator().forEach {
//                Log.d("rinku","author:${it.volumeInfo.authors} \n  publishedDate :${it.volumeInfo.publishedDate} image:${it.volumeInfo.imageLinks}")
//            }

// ********************** Show api data in textView form *********************

//            val myStringBuilder=StringBuilder()
//            for(myData in it.items){
//                myStringBuilder.append(myData.volumeInfo.title)
//                myStringBuilder.append("\n")
//            }
//
//            text1.text=myStringBuilder
        })


// ********************** Show api data in Recycler View *********************


//        mainViewModel.getVolumesResponseLiveData().observe(this,
//            Observer<Any?> { volumesResponse ->
//                if (volumesResponse != null) {
//                    myAdapter.setResults(volumesResponse.getItems())
//                }
//            })

//        mainViewModel.books.observe(this, Observer {
//
//            bookList=
//
//            myAdapter = MyAdapter(baseContext, bookList)
//            myAdapter.notifyDataSetChanged()
//            binding.recylerViewList.adapter = myAdapter
//        })


//
//        })

// ********************** hit api in direct Main Activity  *********************
//        val booksApi=RetrofitHelper.getInstance().create(BooksApi::class.java)

//        lifecycleScope.launch {
//            try {
//                val query="harry"
//                val author="rowling"
//
//                val response=booksApi.getBooks(query,author)
//                if(response.isSuccessful){
//                    val data: Data? =response.body()
//                    Log.d("rinku",data.toString())
//                    if (data != null) {
//                        data.items.forEach {
//                            Log.d("rinku1", it.saleInfo.toString())
//                        }
//                    }
//
//
//                }
//                else{
//
//                }
//            } catch (e:Exception){
//
//            }
//        }


    }

}