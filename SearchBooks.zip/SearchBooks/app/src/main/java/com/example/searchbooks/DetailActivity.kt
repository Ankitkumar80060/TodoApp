package com.example.searchbooks

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.StrictMode
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.searchbooks.databinding.ActivityDetailBinding
import com.example.searchbooks.repository.BooksRepository
import com.example.searchbooks.retrofit.BooksApi
import com.example.searchbooks.retrofit.RetrofitHelper
import com.example.searchbooks.viewmodel.MainViewModel
import com.example.searchbooks.viewmodel.MainViewModelFactory
import java.net.URL

class DetailActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailBinding
    lateinit var mainViewModel: MainViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.bookName.setText(intent.extras!!.getString("title"))
        binding.bookAuthorName.setText(intent.extras!!.getString("author"))
        binding.bookPublishDate.setText(intent.extras!!.getString("published_date"))
//
       



    }



}