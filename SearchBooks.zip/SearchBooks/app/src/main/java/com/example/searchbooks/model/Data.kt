package com.example.searchbooks.model

data class Data(
    val items: List<Item>,
    val kind: String,
    val totalItems: Int
)