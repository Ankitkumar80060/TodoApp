package com.example.searchbooks.model

data class RetailPriceX(
    val amount: Double,
    val currencyCode: String
)