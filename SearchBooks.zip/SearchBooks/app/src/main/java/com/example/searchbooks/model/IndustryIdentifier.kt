package com.example.searchbooks.model

data class IndustryIdentifier(
    val identifier: String,
    val type: String
)