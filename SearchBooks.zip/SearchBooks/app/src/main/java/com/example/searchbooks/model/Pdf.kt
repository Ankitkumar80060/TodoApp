package com.example.searchbooks.model

data class Pdf(
    val acsTokenLink: String,
    val downloadLink: String,
    val isAvailable: Boolean
)