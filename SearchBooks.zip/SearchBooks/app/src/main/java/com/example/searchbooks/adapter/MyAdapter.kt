package com.example.searchbooks.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.searchbooks.DetailActivity
import com.example.searchbooks.R
import com.example.searchbooks.model.Item
import com.example.searchbooks.model.VolumeInfo


class MyAdapter( val bookList: List<Item>) :
    RecyclerView.Adapter<MyAdapter.ViewHolder>() {



    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        val bookImage: ImageView
        val bookName: TextView
        val author: TextView
        val publisheddate: TextView
        val layout:CardView


        init {
            bookImage = itemView.findViewById(R.id.bookItemImage)
            bookName = itemView.findViewById(R.id.book_item_title)
            author = itemView.findViewById(R.id.book_item_author)
            publisheddate = itemView.findViewById(R.id.book_item_publishedDate)
            layout=itemView.findViewById(R.id.cardViewRV)

        }


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view =LayoutInflater.from(parent.context)
            .inflate(R.layout.book_item,parent,false)

        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return bookList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item: Item = bookList.get(position)

        holder.bookName.text=item.volumeInfo.title
        holder.author.text= item.volumeInfo.authors.toString()
        holder.publisheddate.text=item.volumeInfo.publishedDate
//        val book_postion=bookList[position].volumeInfo.title

        val imageUrl: String = item.volumeInfo.imageLinks.smallThumbnail
            .replace("http://", "https://")
        Glide.with(holder.itemView)
            .load(imageUrl)
            .into(holder.bookImage)

        holder.layout.setOnClickListener{
//            Toast.makeText(it.context, "Selected Item :"+book_postion, Toast.LENGTH_SHORT).show()
            val intent= Intent(it.context,DetailActivity::class.java)
            intent.putExtra("title",item.volumeInfo.title)
            intent.putExtra("author",item.volumeInfo.authors.toString())
            intent.putExtra("published_date",item.volumeInfo.publishedDate)
            intent.putExtra("image",imageUrl)
            it.context.startActivity(intent)




        }


    }
}