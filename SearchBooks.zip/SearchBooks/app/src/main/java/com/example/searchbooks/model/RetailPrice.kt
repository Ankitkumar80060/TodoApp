package com.example.searchbooks.model

data class RetailPrice(
    val amountInMicros: Int,
    val currencyCode: String
)