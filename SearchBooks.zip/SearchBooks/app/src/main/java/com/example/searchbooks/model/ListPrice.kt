package com.example.searchbooks.model

data class ListPrice(
    val amount: Double,
    val currencyCode: String
)