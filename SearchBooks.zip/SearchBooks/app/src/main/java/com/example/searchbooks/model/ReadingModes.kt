package com.example.searchbooks.model

data class ReadingModes(
    val image: Boolean,
    val text: Boolean
)